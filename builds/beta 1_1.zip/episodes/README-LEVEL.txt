The game allows for creating custom levels, and even custom sets of levels, called "episodes".

To create an episode, one must first create a text file with .ep file extension. This file is what tells the game to expect a level set.

The .ep file should have a structure as follows:

EPISODE NAME
/folder/path
inventory_size

First line in the file contains the name of the episode, this is the name that shows in game.
Second line is a relative path to folder with levels, it would be wise if the name of the folder was the same as the name of the episode but noone can force you.
Third line should be a whole number representing maximum amount of items player character can have in his inventory at once.

The game will try to find 1.txt in episode folder and crash if it fails to do so

Every level is structured inside .txt file in a specific way:

number_of_signs
Text of sign 1
Text of sign 2
(...)
level_width
level_height
<level data>

I will not explain it further now because I'm lazy.
Go figure it out by opening /spooky house adventure/1.txt or /game testers delight/1.txt
EEEEE MAKARENA

