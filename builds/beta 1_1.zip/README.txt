Ghosthaus ver beta 1.1
Paweł Kopeć
3 September 2022

--------------------------------------------------------------------------------

# Changelog

## [beta 1] - 2022-09-03
## Changes
- Attempting to fix one very specific thing in render

## [beta 1] - 2022-09-03
## Added
- New, improved level data system, that is more user friendly and more foolproof
- Related to above point, improved tile encoding system, which now comes with
  a nice instruction table (see README2 in episodes folder)
- You can customize many things in level data now, such as ghost craziness level
  and guard enemies' behavior, all four of them independently (will be described
  in README2 in episodes folder)
- Level transitions, with score counting
- Episode intro text
- Red door, red key (work same as green counterparts)
- Blue gemstone (useless, but valuable item)
- New, improved ghost AI
- Ghost looks better when it is in the wall
- Now you get instantly killed when trying to walk into an enemy
- You can "skip your turn" (stand still while everything else moves) by pressing
  space (debug only)
- Minor aesthetic changes
- Changes in level layouts
- Began work on 2.txt in /spooky house adventure/ (very unfinished)

## [indev 3] - 2022-08-28
### Added
- Ghost enemy (finally)
- New items (camera, skeleton key, super flashlight)
- Working camera by pressing C, it creates a flash that stuns all enemies for
  a couple turns
- Guard enemies
- Switchable walls, switchable floor
- New switch object, that turns switchable walls to switchable floors and
  vice versa when targeted by player
- More debug information
- There are more possible flashlight levels than just two now
- Changes to tiles and maps
- Changes in level layouts
- Minor aesthetic changes

- Commands
  Reworked the vim easter egg into working commands, if debug mode is enabled
  you can press : to start typing a command:
  :give <item> (green key, flashlight, camera, super flashlight, skeleton key)
  :light up, :light down
  :wq, :q!, :quit, :exit

### Important improvements
- Fixed an annoying problem with input stacking uncontrollably


## [indev 2] - 2022-08-16
### Added
- Dropping items witch D: select an item to drop with arrow keys, then drop
  highlighted item with Enter or cancel with D ( sadly I can't use escape )
- Completely new episode system with .ep files
- Completely new episode select screen
- New episode "GAME TESTER'S DELIGHT"
- Title screen SETTINGS page with option to select how to represent gray color
- Minor changes to tiles and maps
- Minor aesthetic changes (red arrows on title screen ect)
- Changes in level layouts
- Little vim easter egg

## [indev 1] - 2022-08-12
### Added
- 100% of things that are currently here

--------------------------------------------------------------------------------

-> Terminal info:

Terminal of at least 80 columns by 24 rows is required.
(preferably about 120 columns by 34 rows for best experience)
Colored terminal is recommended.
If game fails to set font to unicode it won't run.
Resizing terminal window is not a good idea, although the game corrects itself
when exiting the title screen to start the game, so you can resize the terminal
just before pressing NEW GAME.

Recommended fonts:
On WSL- Consolas and (maybe) Courier New are the best fonts for everything to
display properly.
Consolas looks very nice when bold, but not Courier New.

-> Run flags:

debug (displays some info on top of the screen):
  -d or -debug
no delay (cancels a slight delay that happens every turn before input):
  -nd or -nodelay

-> Game info:

Currently, the "objective" of the game is to reach the not working exit,
which is super easy, barely an inconvenience, and takes about 10 seconds.

-> Game controls:

Arrow keys: movement, interacting with environment, selecting things
Space: skip turn (when debug is enabled)
Enter: confirming things
Page Up/ Page Down: inventory previous/ next page
D: dropping items
C: using the camera
:(colon): enter command mode (when debug is enabled)
F10: exit the game

