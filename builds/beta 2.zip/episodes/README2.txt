Unnecessary information		Useful information
--------------------------------------------------------------------------------
Dec	Hex	Oct		Char	Effect
--------------------------------------------------------------------------------
32	20	040		Space	tile: floor
33	21	041		!	object: switch
34	22	042		"
35	23	043		#	tile: brick wall
36	24	044		$	tile: fake brick wall
37	25	045		%
38	26	046		&
39	27	047		'
40	28	050		(
41	29	051		)
42	2A	052		*
43	2B	053		+	tile: grave
44	2C	054		,	tile: grass
45	2D	055		-
46	2E	056		.	tile: path
47	2F	057		/
48	30	060		0	tile: void
49	31	061		1	tile: sign 1
50	32	062		2	tile: sign 2	
51	33	063		3	tile: sign 3
52	34	064		4	tile: sign 4
53	35	065		5	tile: sign 5
54	36	066		6	tile: sign 6
55	37	067		7	tile: sign 7
56	38	070		8	tile: sign 8
57	39	071		9	tile: sign 9
58	3A	072		:
59	3B	073		;
60	3C	074		<
61	3D	075		=
62	3E	076		>
63	3F	077		?
64	40	100		@	tile: switch wall
65	41	101		A	item: skeleton(almighty) key
66	42	102		B
67	43	103		C	item: camera
68	44	104		D	object: door(simple, unlocked)
69	45	105		E	level exit
70	46	106		F	item: flashlight
71	47	107		G	enemy: ghost
72	48	110		H
73	49	111		I
74	4A	112		J
75	4B	113		K	item: green key
76	4C	114		L	item: red key
77	4D	115		M	object: green door (locked)
78	4E	116		N	object: red door (locked)
79	4F	117		O
80	50	120		P	player starting position
81	51	121		Q
82	52	122		R
83	53	123		S	item: stopwatch
84	54	124		T	tile: tree bottom, but also replaces the
					tile above with tree top
85	55	125		U
86	56	126		V
87	57	127		W
88	58	130		X
89	59	131		Y
90	5A	132		Z
91	5B	133		[
92	5C	134		\
93	5D	135		]
94	5E	136		^
95	5F	137		_	tile: switch floor
96	60	140		`	tile: floor, but also replaces the tile
					above with a table tile (useful if you
					want to have an item lying on a table)
97	61	141		a	enemy: guardian 1 (by default, starts
					left and reverses direction on contact
					with a wall)
98	62	142		b	enemy: guardian 2 (by default, starts
					up and reverses direction on contact
					with a wall)
99	63	143		c	enemy: guardian 3 (by default, starts
					left and rotates counter clockwise on
					contact with a wall)
100	64	144		d	enemy: guardian 4 (by default, starts
					right and rotates clockwise on contact
					with a wall)
101	65	145		e
102	66	146		f	tile: fake rock
103	67	147		g	item: blue gemstone
104	68	150		h	item: red gemstone
105	69	151		i	item: green gemstone
106	6A	152		j
107	6B	153		k
108	6C	154		l
109	6D	155		m
110	6E	156		n
111	6F	157		o
112	70	160		p	tile: pillar
113	71	161		q
114	72	162		r	tile: rock
115	73	163		s
116	74	164		t	tile: table
117	75	165		u
118	76	166		v
119	77	167		w	tile: water
120	78	170		x
121	79	171		y
122	7A	172		z
123	7B	173		{
124	7C	174		|
125	7D	175		}
126	7E	176		~	tile: red water

Using any character not described here will result in placing a void tile, as if
it was replaced by 0.