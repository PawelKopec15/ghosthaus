Ghosthaus ver indev 1
12 August 2022

-> Terminal info:

Terminal of at least 80 columns by 24 rows is required.
(preferably about 100 collumns by 30 rows for best experience)
Colored terminal is recommended.
If game fails to set font to unicode it won't run.
Resizing terminal window is not a good idea, although the game corrects itself when exiting the title screen to start the game, so you can resize the terminal just before pressing NEW GAME.

I found Consolas and maybe Courier New to be the best fonts for everything to display properly.
When bold, Consolas is very nice, but Courier New is very broken.

-> Run flags:

debug (displays some info on top of the screen): -d or -debug
no delay (cancels a slight delay that happens every turn before input): -nd or -nodelay

-> Game info:

Currently, the "objective" of the game is to reach the not working exit, which is super easy and takes 10 seconds.

-> Game controls:

arrow keys: movement, interacting with environment
page up/ page down: inventory previous/ next page
f10: exit the game

